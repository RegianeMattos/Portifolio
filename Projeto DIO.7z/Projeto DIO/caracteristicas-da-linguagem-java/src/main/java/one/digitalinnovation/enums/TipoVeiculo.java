package one.digitalinnovation.enums;

public enum  TipoVeiculo {

    TERRESTRE,
    AQUATICO,
    AEREO

}
