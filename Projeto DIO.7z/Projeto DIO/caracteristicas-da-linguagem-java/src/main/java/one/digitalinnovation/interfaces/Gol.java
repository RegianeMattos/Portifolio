package one.digitalinnovation.interfaces;

public class Gol implements Carro {

    @Override
    public String marca() {

        return "Volkswagen";
    }

    @Override
    public Double valor() {
        return null;
    }
}
